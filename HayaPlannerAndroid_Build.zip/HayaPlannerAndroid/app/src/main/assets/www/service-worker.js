const CACHE="haya-planner-app-v3";
const STATE_CACHE="haya-planner-state-v1";
const STATE_URL="./__haya_reminder_state__";
const ASSETS=["./","./index.html","./manifest.webmanifest","./icon-192.png","./icon-512.png"];
let reminderSettings=null;
let prayerSync=null;

self.addEventListener("install",e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)));self.skipWaiting();});
self.addEventListener("activate",e=>{e.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(k=>k.startsWith("haya-planner-app-")&&k!==CACHE).map(k=>caches.delete(k)));await self.clients.claim();})());});
self.addEventListener("fetch",e=>{if(e.request.method!=="GET")return;e.respondWith(fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r;}).catch(()=>caches.match(e.request).then(r=>r||caches.match("./index.html"))));});

async function saveState(){
  const c=await caches.open(STATE_CACHE);
  await c.put(STATE_URL,new Response(JSON.stringify({reminderSettings,prayerSync}),{headers:{"content-type":"application/json"}}));
}
async function loadState(){
  if(reminderSettings) return;
  try{const c=await caches.open(STATE_CACHE),r=await c.match(STATE_URL);if(r){const s=await r.json();reminderSettings=s.reminderSettings||null;prayerSync=s.prayerSync||null;}}catch(e){}
}
self.addEventListener("message",e=>{if(e.data&&e.data.type==="REMINDER_SETTINGS"){reminderSettings=e.data.settings||reminderSettings;prayerSync=e.data.prayerSync||prayerSync;e.waitUntil(saveState());}});

function ddmmyyyy(d){return `${String(d.getDate()).padStart(2,"0")}-${String(d.getMonth()+1).padStart(2,"0")}-${d.getFullYear()}`;}
function isoDay(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;}
function cleanTime(v){const m=String(v||"").match(/(\d{1,2}):(\d{2})/);return m?`${String(parseInt(m[1],10)).padStart(2,"0")}:${m[2]}`:"";}
async function refreshPrayerTimesInBackground(){
  await loadState();
  if(!prayerSync||!prayerSync.enabled||!reminderSettings) return;
  const now=new Date(), day=isoDay(now);
  if(prayerSync.lastDate===day&&prayerSync.times) return;
  try{
    const city=encodeURIComponent(prayerSync.city||"Amman"),country=encodeURIComponent(prayerSync.country||"Jordan"),method=prayerSync.method||23;
    const r=await fetch(`https://api.aladhan.com/v1/timingsByCity/${ddmmyyyy(now)}?city=${city}&country=${country}&method=${method}&school=0`,{cache:"no-store"});
    const j=await r.json(); if(!j||j.code!==200||!j.data||!j.data.timings)return;
    const map={prayer_fajr:"Fajr",prayer_dhuhr:"Dhuhr",prayer_asr:"Asr",prayer_maghrib:"Maghrib",prayer_isha:"Isha"};
    const times={};
    for(const [id,key] of Object.entries(map)){const t=cleanTime(j.data.timings[key]);if(t){reminderSettings[id].time=t;times[key]=t;}}
    prayerSync.times=times; prayerSync.lastDate=day; prayerSync.lastUpdated="background"; await saveState();
  }catch(e){}
}

self.addEventListener("notificationclick",event=>{
  event.notification.close();
  const d=event.notification.data||{}; let url=d.url||"./";
  if(event.action==="water_done") url=`./?quick=water${parseInt(d.waterAmount||100)}`;
  event.waitUntil((async()=>{const wins=await clients.matchAll({type:"window",includeUncontrolled:true});for(const w of wins){if("focus" in w){await w.focus();if("navigate" in w)await w.navigate(url);return;}}if(clients.openWindow)return clients.openWindow(url);})());
});

self.addEventListener("periodicsync",event=>{
  if(event.tag!=="haya-reminder-check")return;
  event.waitUntil((async()=>{
    await loadState(); await refreshPrayerTimesInBackground(); if(!reminderSettings)return;
    const now=new Date(), hh=String(now.getHours()).padStart(2,"0"), mm=String(now.getMinutes()).padStart(2,"0");
    for(const [id,item] of Object.entries(reminderSettings)){
      if(id==="water"||!item||!item.enabled||!item.time)continue;
      const [th,tm]=item.time.split(":").map(Number),diff=Math.abs((now.getHours()*60+now.getMinutes())-(th*60+tm));
      if(diff<=7) await self.registration.showNotification(item.label,{body:"افتحي Haya Planner وسجلي الحالة.",icon:"icon-192.png",badge:"icon-192.png",tag:`haya-bg-${id}-${now.toDateString()}`,data:{url:`./?reminder=${id}`}});
    }
  })());
});
