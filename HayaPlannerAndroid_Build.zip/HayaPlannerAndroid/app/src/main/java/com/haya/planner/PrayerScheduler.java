package com.haya.planner;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Set;

public final class PrayerScheduler {
    public static final String PREFS = "haya_native";
    public static final String KEY_SCHEDULE = "prayer_schedule";
    public static final String KEY_ADHAN_ENABLED = "adhan_enabled";
    public static final String KEY_DISABLED_PRAYERS = "disabled_prayers";
    public static final ZoneId AMMAN = ZoneId.of("Asia/Amman");

    private PrayerScheduler() {}

    public static void saveSchedule(Context context, JSONArray schedule) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_SCHEDULE, schedule.toString()).apply();
    }

    public static JSONArray loadSchedule(Context context) {
        String s = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_SCHEDULE, "[]");
        try { return new JSONArray(s); } catch (Exception e) { return new JSONArray(); }
    }

    public static boolean isAdhanEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_ADHAN_ENABLED, true);
    }

    public static void setAdhanEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ADHAN_ENABLED, enabled).apply();
        rescheduleSaved(context);
    }

    public static void setPrayerEnabled(Context context, String prayerId, boolean enabled) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> disabled = new HashSet<>(p.getStringSet(KEY_DISABLED_PRAYERS, new HashSet<>()));
        if (enabled) disabled.remove(prayerId); else disabled.add(prayerId);
        p.edit().putStringSet(KEY_DISABLED_PRAYERS, disabled).apply();
        rescheduleSaved(context);
    }

    public static boolean isPrayerEnabled(Context context, String prayerId) {
        Set<String> disabled = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getStringSet(KEY_DISABLED_PRAYERS, new HashSet<>());
        return !disabled.contains(prayerId);
    }

    public static void rescheduleSaved(Context context) {
        JSONArray arr = loadSchedule(context);
        // Cancel every known alarm first, then add current enabled ones.
        for (int i = 0; i < arr.length(); i++) {
            try { cancelEntry(context, arr.getJSONObject(i)); } catch (Exception ignored) {}
        }
        if (!isAdhanEnabled(context)) return;
        for (int i = 0; i < arr.length(); i++) {
            try {
                JSONObject o = arr.getJSONObject(i);
                if (isPrayerEnabled(context, o.optString("prayerId"))) scheduleEntry(context, o);
            } catch (Exception ignored) {}
        }
    }

    public static void scheduleEntry(Context context, JSONObject o) throws Exception {
        String date = o.getString("date"); // yyyy-MM-dd
        String time = o.getString("time"); // HH:mm
        String prayerId = o.getString("prayerId");
        String label = o.optString("label", prayerId);
        LocalDateTime ldt = LocalDateTime.parse(date + "T" + time, DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
        ZonedDateTime zdt = ldt.atZone(AMMAN);
        long when = zdt.toInstant().toEpochMilli();
        if (when <= System.currentTimeMillis() + 5000) return;

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = alarmPendingIntent(context, date, prayerId, label, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } else if (Build.VERSION.SDK_INT >= 23) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    private static void cancelEntry(Context context, JSONObject o) throws Exception {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = alarmPendingIntent(context, o.getString("date"), o.getString("prayerId"), o.optString("label"), PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) am.cancel(pi);
    }

    private static PendingIntent alarmPendingIntent(Context c, String date, String prayerId, String label, int flags) {
        Intent i = new Intent(c, PrayerAlarmReceiver.class);
        i.setAction("com.haya.planner.PRAYER_" + date + "_" + prayerId);
        i.putExtra("prayerId", prayerId);
        i.putExtra("label", label);
        int requestCode = Math.abs((date + prayerId).hashCode());
        return PendingIntent.getBroadcast(c, requestCode, i, flags);
    }
}
