package com.haya.planner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class PrayerAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String prayerId = intent.getStringExtra("prayerId");
        if (!PrayerScheduler.isAdhanEnabled(context) || !PrayerScheduler.isPrayerEnabled(context, prayerId)) return;
        Intent s = new Intent(context, AdhanService.class);
        s.setAction(AdhanService.ACTION_PLAY);
        s.putExtra("prayerId", prayerId);
        s.putExtra("label", intent.getStringExtra("label"));
        if (android.os.Build.VERSION.SDK_INT >= 26) context.startForegroundService(s); else context.startService(s);
    }
}
