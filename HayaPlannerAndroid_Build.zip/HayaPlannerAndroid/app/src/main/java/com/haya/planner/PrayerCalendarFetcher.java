package com.haya.planner;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public final class PrayerCalendarFetcher {
    private PrayerCalendarFetcher() {}

    public static void refreshAsync(Context context) {
        Context app = context.getApplicationContext();
        new Thread(() -> {
            try {
                JSONArray all = new JSONArray();
                YearMonth now = YearMonth.now(PrayerScheduler.AMMAN);
                appendMonth(all, now);
                appendMonth(all, now.plusMonths(1));
                PrayerScheduler.saveSchedule(app, all);
                PrayerScheduler.rescheduleSaved(app);
            } catch (Exception ignored) {
                PrayerScheduler.rescheduleSaved(app);
            }
        }, "HayaPrayerRefresh").start();
    }

    private static void appendMonth(JSONArray out, YearMonth ym) throws Exception {
        String endpoint = "https://api.aladhan.com/v1/calendarByCity/" + ym.getYear() + "/" + ym.getMonthValue()
                + "?city=Amman&country=Jordan&method=23&school=0";
        JSONObject root = new JSONObject(get(endpoint));
        JSONArray days = root.getJSONArray("data");
        Map<String,String> prayers = new LinkedHashMap<>();
        prayers.put("Fajr", "prayer_fajr");
        prayers.put("Dhuhr", "prayer_dhuhr");
        prayers.put("Asr", "prayer_asr");
        prayers.put("Maghrib", "prayer_maghrib");
        prayers.put("Isha", "prayer_isha");
        Map<String,String> labels = new LinkedHashMap<>();
        labels.put("prayer_fajr", "صلاة الفجر");
        labels.put("prayer_dhuhr", "صلاة الظهر");
        labels.put("prayer_asr", "صلاة العصر");
        labels.put("prayer_maghrib", "صلاة المغرب");
        labels.put("prayer_isha", "صلاة العشاء");

        LocalDate today = LocalDate.now(PrayerScheduler.AMMAN);
        LocalDate horizon = today.plusDays(45);
        DateTimeFormatter in = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        for (int i = 0; i < days.length(); i++) {
            JSONObject d = days.getJSONObject(i);
            LocalDate date = LocalDate.parse(d.getJSONObject("date").getJSONObject("gregorian").getString("date"), in);
            if (date.isBefore(today) || date.isAfter(horizon)) continue;
            JSONObject timings = d.getJSONObject("timings");
            for (Map.Entry<String,String> e : prayers.entrySet()) {
                String time = cleanTime(timings.optString(e.getKey()));
                if (time.isEmpty()) continue;
                JSONObject item = new JSONObject();
                item.put("date", date.toString());
                item.put("time", time);
                item.put("prayerId", e.getValue());
                item.put("label", labels.get(e.getValue()));
                out.put(item);
            }
        }
    }

    private static String cleanTime(String s) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,2}):(\\d{2})").matcher(s == null ? "" : s);
        if (!m.find()) return "";
        return String.format(java.util.Locale.US, "%02d:%s", Integer.parseInt(m.group(1)), m.group(2));
    }

    private static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(12000); c.setRequestProperty("Accept", "application/json");
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()))) {
            StringBuilder b = new StringBuilder(); String line;
            while ((line = r.readLine()) != null) b.append(line);
            return b.toString();
        } finally { c.disconnect(); }
    }
}
