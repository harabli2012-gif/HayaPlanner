package com.haya.planner;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;

public class AdhanService extends Service {
    public static final String ACTION_PLAY = "com.haya.planner.PLAY_ADHAN";
    public static final String ACTION_STOP = "com.haya.planner.STOP_ADHAN";
    public static final String KEY_AUDIO_URI = "adhan_audio_uri";
    private static final String CHANNEL = "adhan_channel";
    private MediaPlayer player;

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "الأذان", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("تشغيل الأذان في مواقيت الصلاة");
            ch.setSound(null, null);
            nm.createNotificationChannel(ch);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopPlayback(); stopSelf(); return START_NOT_STICKY;
        }
        String prayerId = intent == null ? "" : intent.getStringExtra("prayerId");
        String label = intent == null ? "وقت الصلاة" : intent.getStringExtra("label");
        startForeground(5001, buildNotification(label, prayerId));
        playSelectedAdhan();
        return START_NOT_STICKY;
    }

    private Notification buildNotification(String label, String prayerId) {
        Intent open = new Intent(this, MainActivity.class);
        open.putExtra("reminder", prayerId);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 7001, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, AdhanService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 7002, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(label == null ? "حان وقت الصلاة" : label)
                .setContentText("اضغطي لفتح Haya Planner وتسجيل الصلاة")
                .setContentIntent(openPi).setAutoCancel(false).setOngoing(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .addAction(new Notification.Action.Builder(null, "إيقاف الأذان", stopPi).build())
                .build();
    }

    private void playSelectedAdhan() {
        try {
            SharedPreferences p = getSharedPreferences(PrayerScheduler.PREFS, Context.MODE_PRIVATE);
            String uriString = p.getString(KEY_AUDIO_URI, "");
            if (uriString.isEmpty()) return;
            Uri uri = Uri.parse(uriString);
            player = new MediaPlayer();
            player.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(this, uri);
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnCompletionListener(mp -> { stopPlayback(); stopSelf(); });
            player.setOnErrorListener((mp, what, extra) -> { stopPlayback(); stopSelf(); return true; });
            player.prepareAsync();
        } catch (Exception e) {
            stopPlayback();
        }
    }

    private void stopPlayback() {
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) {}
            player.release(); player = null;
        }
        stopForeground(true);
    }

    @Override public void onDestroy() { stopPlayback(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
