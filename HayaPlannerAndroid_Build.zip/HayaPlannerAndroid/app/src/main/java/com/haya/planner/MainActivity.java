package com.haya.planner;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int PICK_ADHAN = 9001;
    private static final int REQ_NOTIFY = 9002;
    private WebView webView;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new NativeBridge(), "HayaAndroid");

        requestNotificationPermission();
        requestExactAlarmPermission();
        PrayerScheduler.rescheduleSaved(this);
        PrayerCalendarFetcher.refreshAsync(this);

        String reminder = getIntent().getStringExtra("reminder");
        String url = "file:///android_asset/www/index.html" + (reminder == null || reminder.isEmpty() ? "" : "?reminder=" + Uri.encode(reminder));
        webView.loadUrl(url);
    }

    private void requestNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
        }
    }

    private void requestExactAlarmPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (am != null && !am.canScheduleExactAlarms()) {
                try {
                    Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception ignored) {}
            }
        }
    }

    public class NativeBridge {
        @JavascriptInterface public void chooseAdhanAudio() { runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("audio/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, PICK_ADHAN);
        }); }

        @JavascriptInterface public void testAdhan() { runOnUiThread(() -> {
            Intent s = new Intent(MainActivity.this, AdhanService.class);
            s.setAction(AdhanService.ACTION_PLAY); s.putExtra("prayerId", "test"); s.putExtra("label", "اختبار الأذان");
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        }); }

        @JavascriptInterface public void stopAdhan() { runOnUiThread(() -> {
            Intent s = new Intent(MainActivity.this, AdhanService.class); s.setAction(AdhanService.ACTION_STOP); startService(s);
        }); }

        @JavascriptInterface public boolean hasAdhanAudio() {
            return !getSharedPreferences(PrayerScheduler.PREFS, MODE_PRIVATE).getString(AdhanService.KEY_AUDIO_URI, "").isEmpty();
        }

        @JavascriptInterface public boolean isAdhanEnabled() { return PrayerScheduler.isAdhanEnabled(MainActivity.this); }

        @JavascriptInterface public void setAdhanEnabled(boolean enabled) {
            PrayerScheduler.setAdhanEnabled(MainActivity.this, enabled);
        }

        @JavascriptInterface public void updatePrayerEnabled(String json) {
            try {
                JSONObject o = new JSONObject(json);
                String[] ids = {"prayer_fajr","prayer_dhuhr","prayer_asr","prayer_maghrib","prayer_isha"};
                for (String id : ids) if (o.has(id)) PrayerScheduler.setPrayerEnabled(MainActivity.this, id, o.optBoolean(id, true));
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public String getNativeStatus() {
            boolean audio = hasAdhanAudio(); boolean enabled = isAdhanEnabled();
            return (enabled ? "الأذان التلقائي مفعّل" : "الأذان التلقائي متوقف") + (audio ? " • تم اختيار الصوت" : " • اختاري ملف الأذان");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_ADHAN && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            getSharedPreferences(PrayerScheduler.PREFS, MODE_PRIVATE).edit().putString(AdhanService.KEY_AUDIO_URI, uri.toString()).apply();
            Toast.makeText(this, "تم اختيار صوت الأذان", Toast.LENGTH_SHORT).show();
            webView.evaluateJavascript("window.refreshNativeAdhanStatus && window.refreshNativeAdhanStatus()", null);
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
