#!/usr/bin/env python3
"""Fetch the pinned, compact 604-page Madani Mushaf PNG set for APK builds."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.request import Request, urlopen
import struct
import time

REVISION = "cca352724b9f29e326e077ce142172ddd9006368"
BASE = f"https://raw.githubusercontent.com/Miftah-Fentaw/Quran-Images/{REVISION}/png"
DEST = Path(__file__).resolve().parents[1] / "app/src/main/assets/mushaf/pages"

def fetch(page: int) -> tuple[int, int]:
    target = DEST / f"{page}.png"
    if target.exists():
        data = target.read_bytes()
        if valid(data):
            return page, len(data)
    url = f"{BASE}/{page}.png"
    last_error = None
    for attempt in range(4):
        try:
            request = Request(url, headers={"User-Agent": "HayaPlanner-APK-build/1.6.0"})
            with urlopen(request, timeout=40) as response:
                data = response.read()
            if not valid(data):
                raise ValueError(f"invalid PNG for page {page}")
            target.write_bytes(data)
            return page, len(data)
        except Exception as exc:
            last_error = exc
            time.sleep(attempt + 1)
    raise RuntimeError(f"page {page}: {last_error}")

def valid(data: bytes) -> bool:
    return len(data) > 3000 and data[:8] == b"\x89PNG\r\n\x1a\n" and len(data) >= 24 and data[12:16] == b"IHDR"

def main() -> None:
    DEST.mkdir(parents=True, exist_ok=True)
    failures = []
    total = 0
    with ThreadPoolExecutor(max_workers=16) as pool:
        futures = [pool.submit(fetch, page) for page in range(1, 605)]
        for future in as_completed(futures):
            try:
                _, size = future.result()
                total += size
            except Exception as exc:
                failures.append(str(exc))
    if failures:
        raise SystemExit("Mushaf download failed:\n" + "\n".join(failures[:20]))
    files = sorted(DEST.glob("*.png"), key=lambda p: int(p.stem))
    if len(files) != 604 or [int(p.stem) for p in files] != list(range(1, 605)):
        raise SystemExit(f"Expected pages 1–604; found {len(files)}")
    for important in (1, 2, 49, 293, 304, 604):
        if not valid((DEST / f"{important}.png").read_bytes()):
            raise SystemExit(f"Mushaf page {important} failed validation")
    print(f"Verified and bundled {len(files)} Madani Mushaf pages ({total / 1024 / 1024:.1f} MiB).")

if __name__ == "__main__":
    main()
