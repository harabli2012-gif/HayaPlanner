package com.hayaplanner.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Set;

public final class PrayerScheduler {
    public static final String PREFS = "haya_native_prayers";
    public static final String KEY_SCHEDULE = "amman_schedule";
    public static final String KEY_ADHAN_ENABLED = "adhan_enabled";
    private static final String KEY_DISABLED_PRAYERS = "disabled_prayers";
    public static final ZoneId AMMAN = ZoneId.of("Asia/Amman");
    public static final String[] IDS = {"prayer_fajr", "prayer_dhuhr", "prayer_asr", "prayer_maghrib", "prayer_isha"};

    private PrayerScheduler() {}

    public static void saveSchedule(Context context, JSONArray schedule) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_SCHEDULE, schedule.toString()).apply();
    }

    public static JSONArray loadSchedule(Context context) {
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_SCHEDULE, "[]");
        try { return new JSONArray(raw); } catch (Exception e) { return new JSONArray(); }
    }

    public static boolean isAdhanEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ADHAN_ENABLED, false);
    }

    public static void setAdhanEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ADHAN_ENABLED, enabled).apply();
        if (enabled) PrayerCalendarFetcher.refreshAsync(context); else rescheduleSaved(context);
    }

    public static void setPrayerEnabled(Context context, String prayerId, boolean enabled) {
        if (!isKnownPrayer(prayerId)) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> disabled = new HashSet<>(prefs.getStringSet(KEY_DISABLED_PRAYERS, new HashSet<>()));
        if (enabled) disabled.remove(prayerId); else disabled.add(prayerId);
        prefs.edit().putStringSet(KEY_DISABLED_PRAYERS, disabled).apply();
        rescheduleSaved(context);
    }

    public static boolean isPrayerEnabled(Context context, String prayerId) {
        if (!isKnownPrayer(prayerId)) return false;
        Set<String> disabled = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getStringSet(KEY_DISABLED_PRAYERS, new HashSet<>());
        return !disabled.contains(prayerId);
    }

    public static boolean hasUpcomingPrayer(Context context) {
        JSONArray rows = loadSchedule(context);
        long now = System.currentTimeMillis() + 5000;
        for (int i = 0; i < rows.length(); i++) {
            try {
                JSONObject row = rows.getJSONObject(i);
                if (isPrayerEnabled(context, row.optString("prayerId")) && triggerTime(row) > now) return true;
            } catch (Exception ignored) {}
        }
        return false;
    }

    private static boolean isKnownPrayer(String id) {
        if (id == null) return false;
        for (String prayer : IDS) if (prayer.equals(id)) return true;
        return false;
    }

    public static void rescheduleSaved(Context context) {
        JSONArray rows = loadSchedule(context);
        for (int i = 0; i < rows.length(); i++) {
            try { cancelEntry(context, rows.getJSONObject(i)); } catch (Exception ignored) {}
        }
        if (!isAdhanEnabled(context)) return;
        JSONObject next = null;
        long nextAt = Long.MAX_VALUE;
        for (int i = 0; i < rows.length(); i++) {
            try {
                JSONObject row = rows.getJSONObject(i);
                if (!isPrayerEnabled(context, row.optString("prayerId"))) continue;
                long at = triggerTime(row);
                if (at > System.currentTimeMillis() + 5000 && at < nextAt) {
                    next = row;
                    nextAt = at;
                }
            } catch (Exception ignored) {}
        }
        if (next != null) {
            try { scheduleEntry(context, next); } catch (Exception ignored) {}
        }
    }

    private static void scheduleEntry(Context context, JSONObject row) throws Exception {
        String date = row.getString("date");
        String prayerId = row.getString("prayerId");
        String label = row.optString("label", "حان وقت الصلاة");
        long triggerAt = triggerTime(row);
        if (triggerAt <= System.currentTimeMillis() + 5000) return;

        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        PendingIntent alarm = alarmIntent(context, date, prayerId, label, PendingIntent.FLAG_UPDATE_CURRENT);
        if (Build.VERSION.SDK_INT >= 31 && !alarms.canScheduleExactAlarms()) {
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, alarm);
        } else if (Build.VERSION.SDK_INT >= 23) {
            alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, alarm);
        } else {
            alarms.setExact(AlarmManager.RTC_WAKEUP, triggerAt, alarm);
        }
    }

    private static long triggerTime(JSONObject row) throws Exception {
        String date = row.getString("date");
        String time = row.getString("time");
        LocalDateTime local = LocalDateTime.parse(date + "T" + time,
                DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
        return local.atZone(AMMAN).toInstant().toEpochMilli();
    }

    private static void cancelEntry(Context context, JSONObject row) throws Exception {
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        PendingIntent alarm = alarmIntent(context, row.getString("date"), row.getString("prayerId"),
                row.optString("label", ""), PendingIntent.FLAG_NO_CREATE);
        if (alarm != null) alarms.cancel(alarm);
    }

    private static PendingIntent alarmIntent(Context context, String date, String prayerId, String label, int flag) {
        Intent intent = new Intent(context, PrayerAlarmReceiver.class);
        intent.setAction("com.hayaplanner.app.PRAYER_" + date + "_" + prayerId);
        intent.putExtra("prayerId", prayerId);
        intent.putExtra("label", label);
        int request = Math.abs((date + prayerId).hashCode());
        int flags = flag | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(context, request, intent, flags);
    }
}
