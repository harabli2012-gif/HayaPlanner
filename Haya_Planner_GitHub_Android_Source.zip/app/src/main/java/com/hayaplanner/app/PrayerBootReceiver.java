package com.hayaplanner.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class PrayerBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (PrayerScheduler.isAdhanEnabled(context)) PrayerCalendarFetcher.refreshAsync(context);
        else PrayerScheduler.rescheduleSaved(context);
    }
}
