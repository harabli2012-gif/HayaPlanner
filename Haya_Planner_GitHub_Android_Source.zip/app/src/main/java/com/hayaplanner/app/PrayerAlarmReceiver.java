package com.hayaplanner.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class PrayerAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String prayerId = intent.getStringExtra("prayerId");
        if (!PrayerScheduler.isAdhanEnabled(context) || !PrayerScheduler.isPrayerEnabled(context, prayerId)) return;
        // Keep exactly the next alarm registered; this also rolls the local calendar forward at its edge.
        PrayerScheduler.rescheduleSaved(context);
        if (!PrayerScheduler.hasUpcomingPrayer(context)) PrayerCalendarFetcher.refreshAsync(context);
        Intent service = new Intent(context, AdhanService.class);
        service.setAction(AdhanService.ACTION_PLAY);
        service.putExtra("prayerId", prayerId);
        service.putExtra("label", intent.getStringExtra("label"));
        if (android.os.Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
        else context.startService(service);
    }
}
