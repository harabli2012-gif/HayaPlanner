package com.hayaplanner.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

public class AdhanService extends Service {
    public static final String ACTION_PLAY = "com.hayaplanner.app.PLAY_ADHAN";
    public static final String ACTION_STOP = "com.hayaplanner.app.STOP_ADHAN";
    private static final String CHANNEL = "haya_prayer_adhan";
    private static final int NOTIFICATION_ID = 5101;
    private MediaPlayer player;

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "أذان الصلاة", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("تنبيه وقت الصلاة في عمّان");
            channel.setSound(null, null);
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopPlayback(); stopSelf(); return START_NOT_STICKY;
        }
        String label = intent == null ? "حان وقت الصلاة" : intent.getStringExtra("label");
        String prayerId = intent == null ? "" : intent.getStringExtra("prayerId");
        startForeground(NOTIFICATION_ID, buildNotification(label, prayerId));
        playSelectedAdhan();
        return START_NOT_STICKY;
    }

    private Notification buildNotification(String label, String prayerId) {
        Intent open = new Intent(this, MainActivity.class);
        open.putExtra("reminder", prayerId);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 5102, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, AdhanService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 5103, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(label == null ? "حان وقت الصلاة" : label)
                .setContentText("اضغطي لفتح Haya Planner")
                .setContentIntent(openPi).setAutoCancel(false).setOngoing(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .addAction(new Notification.Action.Builder(null, "إيقاف الأذان", stopPi).build())
                .build();
    }

    private void playSelectedAdhan() {
        try {
            String uri = getSharedPreferences(MainActivity.AUDIO_PREFS, Context.MODE_PRIVATE)
                    .getString(MainActivity.AUDIO_ADHAN, "");
            if (uri.isEmpty()) return;
            player = new MediaPlayer();
            player.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(this, Uri.parse(uri));
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnCompletionListener(mp -> { stopPlayback(); stopSelf(); });
            player.setOnErrorListener((mp, what, extra) -> { stopPlayback(); stopSelf(); return true; });
            player.prepareAsync();
        } catch (Exception e) {
            stopPlayback();
        }
    }

    private void stopPlayback() {
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
    }

    @Override public void onDestroy() { stopPlayback(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
