package com.hayaplanner.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * A minimal Android shell for the offline Haya Planner interface.
 * Application data remains in this WebView's private storage.
 */
public class MainActivity extends Activity {
    private static final String DOMAIN = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + DOMAIN + "/assets/index.html";
    private static final int CHOOSE_JSON = 701;
    private static final int SAVE_JSON = 702;

    private WebView webView;
    private android.webkit.ValueCallback<Uri[]> fileChooser;
    private String pendingBackup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255,248,251));
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setDefaultTextEncodingName("UTF-8");

        // The app's HTML has a secure, stable HTTPS origin. That makes localStorage
        // persistent between normal app launches without loading an external website.
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !DOMAIN.equals(uri.getHost())) return null;
                String path = uri.getPath();
                if (path == null || !path.startsWith("/assets/")) return forbidden();
                String file = path.substring("/assets/".length());
                if (file.isEmpty() || file.contains("..") || file.contains("\\") || file.startsWith("/")) return forbidden();
                try {
                    InputStream body = getAssets().open(file);
                    String mime = "application/octet-stream";
                    if (file.endsWith(".html")) mime = "text/html";
                    else if (file.endsWith(".js")) mime = "text/javascript";
                    else if (file.endsWith(".css")) mime = "text/css";
                    else if (file.endsWith(".png")) mime = "image/png";
                    else if (file.endsWith(".svg")) mime = "image/svg+xml";
                    else if (file.endsWith(".webmanifest") || file.endsWith(".json")) mime = "application/json";
                    return new WebResourceResponse(mime, "UTF-8", body);
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                            java.util.Collections.emptyMap(),
                            new java.io.ByteArrayInputStream(new byte[0]));
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && DOMAIN.equals(uri.getHost())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception ex) { Toast.makeText(MainActivity.this, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show(); }
                    return true;
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                    android.webkit.ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileChooser != null) fileChooser.onReceiveValue(null);
                fileChooser = callback;
                Intent open = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                open.addCategory(Intent.CATEGORY_OPENABLE);
                open.setType("application/json");
                open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivityForResult(open, CHOOSE_JSON); }
                catch (Exception e) {
                    fileChooser.onReceiveValue(null);
                    fileChooser = null;
                    Toast.makeText(MainActivity.this, "تعذر فتح ملف JSON", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        // Only the local trusted app page should load in this WebView.
        // Other URLs open in the system browser.
        webView.addJavascriptInterface(new BackupBridge(), "HayaAndroid");
        webView.loadUrl(START_URL);
    }

    private WebResourceResponse forbidden() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden",
                java.util.Collections.emptyMap(),
                new java.io.ByteArrayInputStream(new byte[0]));
    }

    public final class BackupBridge {
        @JavascriptInterface
        public void exportJson(String json, String requestedName) {
            runOnUiThread(() -> {
                if (pendingBackup != null) {
                    Toast.makeText(MainActivity.this, "أكملي حفظ النسخة أولًا", Toast.LENGTH_SHORT).show();
                    return;
                }
                pendingBackup = json;
                String safe = requestedName == null ? "Haya_Planner_backup.json" :
                        requestedName.replaceAll("[^A-Za-z0-9_.-]", "_");
                Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                save.addCategory(Intent.CATEGORY_OPENABLE);
                save.setType("application/json");
                save.putExtra(Intent.EXTRA_TITLE, safe);
                try { startActivityForResult(save, SAVE_JSON); }
                catch (Exception e) {
                    pendingBackup = null;
                    Toast.makeText(MainActivity.this, "تعذر فتح نافذة الحفظ", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CHOOSE_JSON) {
            if (fileChooser != null) {
                fileChooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileChooser = null;
            }
        } else if (requestCode == SAVE_JSON) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackup != null) {
                try (OutputStream stream = getContentResolver().openOutputStream(data.getData())) {
                    if (stream == null) throw new IOException("Output stream unavailable");
                    stream.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                    stream.flush();
                    Toast.makeText(this, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(this, "تعذر حفظ النسخة، أعيدي المحاولة", Toast.LENGTH_LONG).show();
                }
            }
            pendingBackup = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("(function(){var x=document.getElementById('mushafReader');" +
                    "if(x&&!x.classList.contains('hidden')){document.getElementById('mushafClose').click();return true;}" +
                    "return false;})()", answer -> {
                if (!"true".equals(answer)) MainActivity.super.onBackPressed();
            });
        } else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (fileChooser != null) { fileChooser.onReceiveValue(null); fileChooser = null; }
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
